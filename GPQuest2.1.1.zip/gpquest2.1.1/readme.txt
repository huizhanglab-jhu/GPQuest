20200703 version GPQuest 2.1.1
updates
1. fix some bugs due to python2 migrated to python3
2. add support to TMT11plex

20200617 version GPQuest 2.1.0
updates
1. add support for isotope peaks validation
2. migrate from python2 to python3

1. Install anaconda from https://www.anaconda.com/products/individual (Python 3.7)
2. In conda enviroment, use pip install gpquest-2.0.0-cp37-cp37m-win_amd64.whl to install gpquest 2.0 package
3. Double click run_gpquest.bat in the exe folder to start GPQuest 2.0 

Q&A:
1. How to start GPQuest 2.1?
If some dependency packages are not installed automatically, you may not start GPQuest 2.0 correctly.
To solve the problem, please:
1) open the command line terminal and cd to the exe folder. 
2) run run_gpquest.bat in the command line mode to check the error message and install the required modules using pip.

2. Where is the template parameter file?
It is in the folder 'sample'.
